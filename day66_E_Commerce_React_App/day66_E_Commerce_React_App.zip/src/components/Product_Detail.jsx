import React from 'react'

const Product_Detail = () => {
  return (
    <div>Product_Detail</div>
  )
}

export default Product_Detail