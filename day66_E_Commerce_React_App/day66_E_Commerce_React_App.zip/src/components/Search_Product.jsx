import React from 'react'

const Search_Product = () => {
  return (
    <div>Search_Product</div>
  )
}

export default Search_Product;